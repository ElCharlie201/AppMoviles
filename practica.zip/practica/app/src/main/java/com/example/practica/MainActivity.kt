package com.example.practica

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.DrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.example.practica.ui.theme.PracticaTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val TAG = "MainActivity"

class MainActivity : ComponentActivity() {
    private var keepSplash = true

    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        splashScreen.setKeepOnScreenCondition { keepSplash }
        lifecycleScope.launch {
            delay(3000)
            keepSplash = false
        }

        ShowToast("Funcion onCreate()")
        enableEdgeToEdge()
        setContent {
            PracticaTheme {
                ViewContainer()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        ShowToast("Funcion onStart()")
    }

    override fun onResume() {
        super.onResume()
        ShowToast("Funcion onResume()")
    }

    override fun onPause() {
        super.onPause()
        ShowToast("Funcion onPause()")
    }

    override fun onStop() {
        super.onStop()
        ShowToast("Funcion onStop()")
    }

    override fun onDestroy() {
        super.onDestroy()
        ShowToast("Funcion onDestroy()")
    }

    override fun onRestart() {
        super.onRestart()
        ShowToast("Funcion onRestart()")
    }

    fun ShowToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        Log.i(TAG, message)
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Preview(name = "Español", showBackground = true, locale = "es-rMX")
@Preview(showBackground = true, device = "spec:width=411dp,height=891dp,orientation=landscape")
@Composable
fun ViewContainer() {

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val snackbarMsg = stringResource(R.string.snackbar_msg)
    val snackbarAction = stringResource(R.string.snackbar_action)
    val context = LocalContext.current
    val draweState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    ModalNavigationDrawer(
        drawerState = draweState,
        drawerContent = {
            ModalDrawerSheet {
                Text("Menu de navegacion", modifier = Modifier.padding(16.dp))
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text("Inicio") },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { draweState.close() }
                    }
                )
            }
        }

    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(stringResource(R.string.home_screen)) },
                    colors = topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.secondary,
                        titleContentColor = Color.White
                    ),
                    navigationIcon = {
                        IconButton(onClick = {
                            coroutineScope.launch { draweState.open() }
                        }) {
                            Icon(
                                Icons.Default.Menu, contentDescription = "Abrir Menu"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { openWebScreen(context) }) {
                            Icon(
                                imageVector = Icons.Default.AddLink,
                                contentDescription = "Link Web",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { openSecondActivity(context) }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Compartir",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { openSettings(context) }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Configuracion",
                                tint = Color.White
                            )
                        }

                        DropDownMenu()
                    }
                )
            },
            bottomBar = {
                BottomAppBar(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.primary,
                ) {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        text = stringResource(R.string.bottom_app_bar),
                        color = Color.White,
                        fontSize = 18.sp,
                    )
                }
            },
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = Color.Black,
                        contentColor = Color.White
                    )
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    scope.launch {
                        snackbarHostState.showSnackbar(
                            message = snackbarMsg,
                            actionLabel = snackbarAction,
                            duration = SnackbarDuration.Short
                        )
                    }
                }) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = stringResource(R.string.home_fab_text)
                    )
                }
            }
        ) { innerPadding ->
            ContentView(Modifier.padding(innerPadding))
        }
    }
}

@Composable
fun ContentView(modifier: Modifier = Modifier) {
    var counter by rememberSaveable { mutableStateOf(0) }
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Red)
    ) {
        item {
            Image(
                painter = painterResource(id = R.drawable.android1920x1080),
                contentDescription = "Ilustración de Android",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            )
            Row(modifier = Modifier.padding(top = 2.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.outline_cottage_24),
                    contentDescription = "Like",
                    modifier = Modifier
                        .clickable { counter++ }
                        .padding(start = 12.dp)
                )
                Text(
                    text = counter.toString(),
                    fontSize = 20.sp,
                    color = Color.White,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            Text(
                text = stringResource(R.string.materia),
                fontSize = 24.sp,
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(R.string.nombre),
                fontSize = 20.sp,
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Text(
                text = stringResource(R.string.apellido),
                fontSize = 20.sp,
                color = Color.White,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            LazyRow(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
            ) {
                item {
                    Row(modifier = Modifier.padding(bottom = 24.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img1),
                            contentDescription = "Imagen 1",
                            modifier = Modifier
                                .size(200.dp)
                                .padding(5.dp),
                            contentScale = ContentScale.Crop
                        )
                        Image(
                            painter = painterResource(id = R.drawable.img2),
                            contentDescription = "Imagen 2",
                            modifier = Modifier
                                .size(200.dp)
                                .padding(5.dp),
                            contentScale = ContentScale.Crop
                        )
                        Image(
                            painter = painterResource(id = R.drawable.img3),
                            contentDescription = "Imagen 3",
                            modifier = Modifier
                                .size(200.dp)
                                .padding(5.dp),
                            contentScale = ContentScale.Crop
                        )
                        Image(
                            painter = painterResource(id = R.drawable.img4),
                            contentDescription = "Imagen 4",
                            modifier = Modifier
                                .size(200.dp)
                                .padding(5.dp),
                            contentScale = ContentScale.Crop
                        )
                        Image(
                            painter = painterResource(id = R.drawable.img5),
                            contentDescription = "Imagen 5",
                            modifier = Modifier
                                .size(200.dp)
                                .padding(5.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        }
    }
}

fun openWebScreen(context: Context) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://aguascalientes.tecnm.mx/"))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Error al abrir la página web", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir la URL: ${e.message}")
    }
}

fun openSecondActivity(context: Context) {
    try {
        context.startActivity(Intent(context, SecondActivity::class.java))
    } catch (e: Exception) {
        Toast.makeText(context, "Error al abrir la segunda pantalla", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir SecondActivity: ${e.message}")
    }
}

fun openCalendar(context: Context) {
    try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_CALENDAR)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No se encontró aplicación de calendario", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir calendario: ${e.message}")
    }
}

fun openAlarm(context: Context) {
    try {
        context.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
    } catch (e: Exception) {
        Toast.makeText(context, "No se encontró aplicación de alarma", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir alarma: ${e.message}")
    }
}

fun openFiles(context: Context) {
    try {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No se encontró administrador de archivos", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir archivos: ${e.message}")
    }
}

fun openDownloads(context: Context) {
    try {
        context.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
    } catch (e: Exception) {
        Toast.makeText(context, "No se encontraron descargas", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir descargas: ${e.message}")
    }
}

fun openProfile(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
    } catch (e: Exception) {
        Toast.makeText(context, "Perfil de usuario", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir perfil: ${e.message}")
    }
}

fun openSettings(context: Context) {
    try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS))
    } catch (e: Exception) {
        Toast.makeText(context, "Error al abrir configuración", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al abrir configuración: ${e.message}")
    }
}

fun logout(context: Context) {
    try {
        Toast.makeText(context, "Cerrando sesión...", Toast.LENGTH_SHORT).show()
        (context as? ComponentActivity)?.finish()
    } catch (e: Exception) {
        Toast.makeText(context, "Error al cerrar sesión", Toast.LENGTH_SHORT).show()
        Log.e(TAG, "Error al cerrar sesión: ${e.message}")
    }
}

@Composable
fun DropDownMenu() {
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(
                imageVector = Icons.Default.MoreVert,
                contentDescription = stringResource(R.string.options_menu),
                tint = Color.White
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = { Text(stringResource(R.string.Calendario)) },
                onClick = { expanded = false; openCalendar(context) },
                leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) }
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.Alarma)) },
                onClick = { expanded = false; openAlarm(context) },
                leadingIcon = { Icon(Icons.Default.Alarm, contentDescription = null) }
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.Archivos)) },
                onClick = { expanded = false; openFiles(context) },
                leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null) }
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.Descargas)) },
                onClick = { expanded = false; openDownloads(context) },
                leadingIcon = { Icon(Icons.Default.Download, contentDescription = null) }
            )

            HorizontalDivider()

            DropdownMenuItem(
                text = { Text(stringResource(R.string.profile)) },
                onClick = { expanded = false; openProfile(context) },
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.config)) },
                onClick = { expanded = false; openSettings(context) },
                leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) }
            )

            HorizontalDivider()

            DropdownMenuItem(
                text = { Text(stringResource(R.string.logout)) },
                onClick = { expanded = false; logout(context) },
                leadingIcon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null) }
            )
        }
    }
}
